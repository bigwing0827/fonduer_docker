## fonduer-tutorials/wiki フォルダ

アメリカ大統領の出生地の抽出
この上級チュートリアルでは、Fonduerアプリケーションを構築して、アメリカの大統領のwikipedia htmlページから出生地を抽出するタスクに取り組みます。これはリッチなフォーマットのデータから知識ベースを構築する例です。

チュートリアル全体はpresident_place_of_birth_tutorial.ipynbで見ることができます。チュートリアルを実行する前に、以下のことが必要です。

./download_data.sh を実行し、チュートリアルで使用するデータを取得します。
pob_presidents という名前の postgres データベースを作成します。postgresがインストールされていると仮定して、createdb pob_presidentsを実行すればよいのです。
例
例えば、簡略化したデータシートのスニペットです。


目標は、(大統領の名前、出生地)の関係ペアを抽出することである。
("Abraham Lincoln", "Sinking Spring Farm")