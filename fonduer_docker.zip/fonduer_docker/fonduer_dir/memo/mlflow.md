## Fonduer実行環境
- Fonduer-MLFlow環境をdockerで構築する。

***
## 1. 構築(初回時)
### 仮想環境(任意)
```sh
python3 -m venv .venv
source .venv/bin/activate
```
- python train.py --conn_string postgresql://user:postgre@localhost:5432/pob_presidents
- mlflow run ./ -P conn_string=postgresql://user:postgre@localhost:5432/pob_presidents --no-conda

- mlflow models serve -m fonduer_label_model -w 1 --no-conda
- mlflow models serve -m fonduer_emmental_model -w 1 --env-manager=local
- curl -X POST -H "Content-Type:application/json; format=pandas-split" \
  --data '{"columns":["html_path"], "data":["data/new/Al_Gore.html"]}' \
  http://127.0.0.1:5000/invocations

***
## Tips
- 日本語サイト
  - https://www.nuomiphp.com/github/ja/5fcdb7cdf23d39006f66ccb7.html
- FutureWarning: `--no-conda` is deprecated and will be removed in a future MLflow release. Use `--env-manager=local` instead.