## Fonduer実行環境
- Fonduer実行環境をdockerで構築する。

***
## 1. 構築(初回時)
### 仮想環境(任意)
```sh
python3 -m venv .venv
source .venv/bin/activate
```
### docker-composeインストール
```sh
sudo apt update
sudo apt install docker-compose
```
### docker操作シェルスクリプト
- 実行権限付与
```sh
chmod u+x oper_docker.sh
```

<details>
<summary>【Tip：oper_docker.sh の使い方】</summary>

- `oper_docker.sh`は`docker-compose.yml` のオペレーション用スクリプトです。
- オプションを指定することで、buildやdownなどが可能です。
- 詳細は、以下でヘルプ表示して確認してください。
  ```sh
  ./oper_docker.sh -h
  ```
</details>

### コンテナ作成・起動
```sh
./oper_docker.sh -b
```
- dockerコンテナ内のデータ永続化として、workspaceフォルダが作成されるので、このworkspaceフォルダでdockerコンテナとのデータの入出力を行う。
- `http://127.0.0.1:8888/lab?` でjupyterlabの利用が可能。

<details>
<summary>【Tip：Docker HubのRate Limitに引っかかる】</summary>

- 問題：Docker Hubからコンテナイメージをpullしようとした際、Rate Limitに引っ掛かり、buildやupができない。
- エラーログ例：`You have reached your pull rate limit. You may increase the limit by authenticating and upgrading: https://www.docker.com/increase-rate-limit`
- 対応案1：しばらく時間を置く
- 対応案2：待てないなら、Docker Hubアカウント作ってログインする(Rate Limitが緩和される)
  - `https://hub.docker.com/`でアカウント登録し、以下でログインしておく。
  ```sh
  sudo docker login
  ```
</details>

***
## 2. 実行(2回目以降)
### 仮想環境(任意)
```sh
source .venv/bin/activate
```
### コンテナ起動
- コンテナ起動しているか確認
```sh
./oper_docker.sh -p
```
- コンテナ起動していなかった場合、以下でコンテナ起動する
```sh
./oper_docker.sh -s
```
- `http://127.0.0.1:8888/lab?` でjupyterlabの利用が可能。

<details>
<summary>【Tip：dockerコンテナに入る】</summary>

- execコマンドを使う。
  ```sh
  ## fonduer(jupyterlab) コンテナに入る
  sudo docker-compose exec fonduer bash
  ## postgres コンテナに入る
  sudo docker-compose exec fonduer-postgres bash
  ```
</details>

***
## 3. サンプル実行(任意)
### jupyterlabでサンプル実行
- jupyterlabを利用する。

<details>
<summary>【Tip：postgresql(docker)の接続がうまくいかない】</summary>

- postgresqlのホスト名を確認してください。
- デフォルトでは`fonduer-postgres`がpostgresqlのホスト名。 (docker-compose.yml記載)
- 以下、コマンド例
  ```sh
  createdb -h fonduer-postgres ${dbname}
  URL = 'postgresql://fonduer-postgres:5432/' + ${dbname}
  ```
</details>
