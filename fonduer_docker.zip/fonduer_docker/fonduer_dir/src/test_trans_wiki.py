import os
import sys
import logging
from fonduer import Meta, init_logging
from fonduer.parser.preprocessors import HTMLDocPreprocessor
from fonduer.parser import Parser
from fonduer.parser.models import Document, Sentence
from fonduer.candidates.models import mention_subclass
from fonduer.candidates.matchers import LambdaFunctionMatcher, Intersect, Union
from fonduer.utils.data_model_utils import get_row_ngrams
from fonduer.candidates import MentionNgrams
from fonduer.candidates import MentionExtractor
from fonduer.candidates.models import Mention
from fonduer.candidates.models import candidate_subclass
from fonduer.candidates import CandidateExtractor
from fonduer.features import Featurizer

def postgresql():
    #! dropdb --if-exists pob_presidents #Uncomment to remove databases created in previous runs
    #! createdb pob_presidents
    return

# KBC Initialization
def KBC_Initialization():
    PARALLEL = 4 # assuming a quad-core machine
    ATTRIBUTE = "pob_presidents"
    POS_USER = "postgre_user"
    POS_PASS = "postgre_pass"
    #conn_string = 'postgresql://localhost:5432/' + ATTRIBUTE
    conn_string = f'postgresql://{POS_USER}:{POS_PASS}@localhost:5432/postgres' + ATTRIBUTE

    ## Parsing and Transforming the Input Documents into Unified Data Models
    # Configure logging for Fonduer
    init_logging(log_dir="logs")
    session = Meta.init(conn_string).Session()

    ## Configuring an HTMLDocPreprocessor
    docs_path = "data/presidents/"
    doc_preprocessor = HTMLDocPreprocessor(docs_path)

    ## Configuring a Parser
    corpus_parser = Parser(session, structural=True, lingual=True)
    #%time corpus_parser.apply(doc_preprocessor, parallelism=PARALLEL)
    corpus_parser.apply(doc_preprocessor, parallelism=PARALLEL)
    
    ## check
    print(f"Documents: {session.query(Document).count()}")
    print(f"Sentences: {session.query(Sentence).count()}")
    ##


# Dividing the Corpus into Test and Train
def Divid_Data():
    docs = session.query(Document).order_by(Document.name).all()
    ld = len(docs)
    train_docs = set()
    dev_docs = set()
    test_docs = set()
    splits = (0.7, 0.85)
    data = [(doc.name, doc) for doc in docs]
    data.sort(key=lambda x: x[0])
    for i, (doc_name, doc) in enumerate(data):
        if i < splits[0] * ld:
            train_docs.add(doc)
        elif i < splits[1] * ld:
            dev_docs.add(doc)
        else:
            test_docs.add(doc)
    from pprint import pprint
    pprint([x.name for x in train_docs])
    ## 


# Mention Extraction, Candidate Extraction Multimodal Featurization
def Mention_Extraction():
    Presidentname = mention_subclass("Presidentname")
    Placeofbirth = mention_subclass("Placeofbirth")

## name matcher
def mention_span_matches_file_name(mention):
    president_name_string = mention.get_span()
    file_name = mention.sentence.document.name.replace("_", " ")
    if president_name_string == file_name:
        return True
    else:
        return False

def mention_matcher():
    president_name_matcher = LambdaFunctionMatcher(func=mention_span_matches_file_name)

## birth matcher
def is_in_birthplace_table_row(mention):
    if not mention.sentence.is_tabular():
        return False
    ngrams = get_row_ngrams(mention, lower=True)
    birth_place_words = set(["birth", "place"])
    if birth_place_words <= set(ngrams):
        return True
    else:
        return False

def birthplace_left_aligned_to_punctuation(mention):
    # Return false, if the cell containing the text candidate does not have any reference
    # to `sentence` objects
    for sentence in mention.sentence.cell.sentences:
        sentence_parts = sentence.text.split(",")
        for sentence_part in sentence_parts:
            if sentence_part.startswith(mention.get_span()):
                return True
    return False

def no_commas_in_birth_place(mention):
    if "," in mention.get_span():
        return False
    else:
        return True

def birth_matcher():
    birth_place_in_labeled_row_matcher = LambdaFunctionMatcher(
        func=is_in_birthplace_table_row
    )
    birth_place_in_labeled_row_matcher.longest_match_only = False
    birth_place_no_commas_matcher = LambdaFunctionMatcher(func=no_commas_in_birth_place)
    birth_place_left_aligned_matcher = LambdaFunctionMatcher(
        func=birthplace_left_aligned_to_punctuation
    )
    place_of_birth_matcher = Intersect(
        birth_place_in_labeled_row_matcher,
        birth_place_no_commas_matcher,
        birth_place_left_aligned_matcher,
    )

# Define a Mention's `MentionSpace`
def MentionExtraction():
    presname_ngrams = MentionNgrams(n_max=4, n_min=2)
    placeofbirth_ngrams = MentionNgrams(n_max=3)
    ## Running Mention Extraction 
    mention_extractor = MentionExtractor(
        session,
        [Presidentname, Placeofbirth],
        [presname_ngrams, placeofbirth_ngrams],
        [president_name_matcher, place_of_birth_matcher],
    )
    ## 
    mention_extractor.apply(docs, parallelism=PARALLEL)
    num_names = session.query(Presidentname).count()
    num_pobs = session.query(Placeofbirth).count()
    print(
        f"Total Mentions: {session.query(Mention).count()} ({num_names} names, {num_pobs} places of birth)"
    )
    ## 


# Candidate Extraction
def Candidate_Extraction():
    PresidentnamePlaceofbirth = candidate_subclass(
        "PresidentnamePlaceofbirth", [Presidentname, Placeofbirth]
    )
    ## Run the CandidateExtractor
    candidate_extractor = CandidateExtractor(session, [PresidentnamePlaceofbirth])
    ## 
    for i, docs in enumerate([train_docs, dev_docs, test_docs]):
        candidate_extractor.apply(docs, split=i, parallelism=PARALLEL)
    print(
        f"Number of Candidates in split={i}: {session.query(PresidentnamePlaceofbirth).filter(PresidentnamePlaceofbirth.split == i).count()}"
    )
    train_cands = candidate_extractor.get_candidates(split=0)
    dev_cands = candidate_extractor.get_candidates(split=1)
    test_cands = candidate_extractor.get_candidates(split=2)
    ## 

# Multimodal Featurization
def Multimodal_Featurization():
    featurizer = Featurizer(session, [PresidentnamePlaceofbirth])
    #%time featurizer.apply(split=0, train=True, parallelism=PARALLEL)
    #%time F_train = featurizer.get_feature_matrices(train_cands)
    ## 
    print(F_train[0].shape)
    #%time featurizer.apply(split=1, parallelism=PARALLEL)
    #%time F_dev = featurizer.get_feature_matrices(dev_cands)
    print(F_dev[0].shape)
    ##
    #%time featurizer.apply(split=2, parallelism=PARALLEL)
    #%time F_test = featurizer.get_feature_matrices(test_cands)
    print(F_test[0].shape)

if __name__ == '__main__':
    # args
    args = sys.argv
    if len(args) != 1:
        print('INCORRECT Arguments')
        exit()
    # 