#!/bin/bash

## docker-compose ps
ps () {
    echo "コンテナの状態を表示します...(1/1)"
    echo "Stateが UP:起動中, Exit:停止中"
    docker-compose ps
}

## docker-compose start
start () {
    echo "起動中のコンテナを停止中...(1/2)"
    docker-compose stop
    echo "コンテナ起動中...(2/2)"
    docker-compose start
}

## docker-compose up
up () {
    echo "起動中のコンテナを停止中...(1/2)"
    docker-compose stop
    echo "コンテナ起動中...(2/2)"
    docker-compose up -d
    # docker-compose up -d --build
}

## docker-compose build
build() {
    echo "起動中のコンテナを停止中...(1/3)"
    docker-compose stop
    echo "コンテナ構築中...(2/3)"
    #docker-compose build --no-cache
    docker-compose build
    echo "コンテナ起動中...(3/3)"
    docker-compose up -d
}

## docker-compose down
down () {
    echo "コンテナ、イメージ、ネットワークを一括完全消去します"
    # echo "コンテナ、イメージ、ボリューム、ネットワークを一括完全消去します"
    read -p "本当に消去していいですか? (y/n) : " yn
    case $yn in
        [Yy]* ) 
            echo "完全消去中...(1/1)"
            docker-compose down --rmi all --remove-orphans ;;
            #docker-compose down --rmi all --volumes --remove-orphans ;;
        [Nn]* ) 
            exit ;;
        * ) 
            echo "Please answer Yes or No.";;
    esac
}

## help message
help () {
    echo $1
    cat << _EOF_
    Usage:
    $(basename $0) [OPTION]

    Description:
    "$(pwd)/docker-compose.yml" のオペレーション用スクリプトです。

    Options:
    -p psを実行します。docker-composeで作成したコンテナの状態を表示します。
    -s startを実行します。現在起動しているdocker-composeコンテナを停止してから、作成済みのコンテナを起動します。
    -u upを実行します。現在起動しているdocker-composeコンテナを停止してから、キャッシュを使ってコンテナの構築・起動します。
    -b buildを実行します。no-cacheでdocker-composeコンテナを作り直してから起動します。Dockerfileを更新した場合はこちらを実行してください。
    -d downを実行します。docker-composeコンテナ、イメージ、ネットワークを一括完全消去します。
    -h ヘルプを表示します。

_EOF_

    exit 0
}

## option
if [ $# -eq 1 ]; then
    while getopts :psubdh OPT; do
        case $OPT in
            p ) 
                ps
                exit 0;;
            s ) 
                start
                exit 0;;
            u ) 
                up
                exit 0;;
            b ) 
                build
                exit 0;;
            d ) 
                down
                exit 0;;
            h ) 
                help
                exit 0;;
            :|\? ) 
                echo "Please check the options: ${0} -h"
                exit -1;;
        esac
    done
else
    echo "Usage: ${0} [OPTION]"
    exit -1
fi
